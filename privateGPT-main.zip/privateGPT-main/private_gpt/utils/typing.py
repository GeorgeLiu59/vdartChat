from typing import TypeVar

T = TypeVar("T")
K = TypeVar("K")
V = TypeVar("V")
