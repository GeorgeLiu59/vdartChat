"""private-gpt server."""
