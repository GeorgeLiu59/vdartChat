"""Deprecated Openai compatibility endpoint."""
